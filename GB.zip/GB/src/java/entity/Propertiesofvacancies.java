/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "propertiesofvacancies", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Propertiesofvacancies.findAll", query = "SELECT p FROM Propertiesofvacancies p")
    , @NamedQuery(name = "Propertiesofvacancies.findById", query = "SELECT p FROM Propertiesofvacancies p WHERE p.id = :id")
    , @NamedQuery(name = "Propertiesofvacancies.findByCond", query = "SELECT p FROM Propertiesofvacancies p WHERE p.categoriesVacid = :idCategory AND p.type=:Type")
    , @NamedQuery(name = "Propertiesofvacancies.findByName", query = "SELECT p FROM Propertiesofvacancies p WHERE p.name = :Name AND p.categoriesVacid = :idCategory AND p.type=:Type")})
public class Propertiesofvacancies implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertiesofVacanciesid")
    private Collection<Requirementsdata> requirementsdataCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertiesofVacanciesid")
    private Collection<Dutiesdata> dutiesdataCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "propertiesofVacanciesid")
    private Collection<Opportunitiesdata> opportunitiesdataCollection;

    @Basic(optional = false)
    @NotNull
    @Column(name = "Type")
    private short type;

    @JoinColumn(name = "CategoriesVac_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Categoriesvac categoriesVacid;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "Name")
    private String name;

    public Propertiesofvacancies() {
    }

    public Propertiesofvacancies(Integer id) {
        this.id = id;
    }

    public Propertiesofvacancies(Integer id, String typeValue, String name) {
        this.id = id;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Propertiesofvacancies)) {
            return false;
        }
        Propertiesofvacancies other = (Propertiesofvacancies) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Propertiesofvacancies[ id=" + id + " ]";
    }

    public Categoriesvac getCategoriesVacid() {
        return categoriesVacid;
    }

    public void setCategoriesVacid(Categoriesvac categoriesVacid) {
        this.categoriesVacid = categoriesVacid;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    @XmlTransient
    public Collection<Requirementsdata> getRequirementsdataCollection() {
        return requirementsdataCollection;
    }

    public void setRequirementsdataCollection(Collection<Requirementsdata> requirementsdataCollection) {
        this.requirementsdataCollection = requirementsdataCollection;
    }

    @XmlTransient
    public Collection<Dutiesdata> getDutiesdataCollection() {
        return dutiesdataCollection;
    }

    public void setDutiesdataCollection(Collection<Dutiesdata> dutiesdataCollection) {
        this.dutiesdataCollection = dutiesdataCollection;
    }

    @XmlTransient
    public Collection<Opportunitiesdata> getOpportunitiesdataCollection() {
        return opportunitiesdataCollection;
    }

    public void setOpportunitiesdataCollection(Collection<Opportunitiesdata> opportunitiesdataCollection) {
        this.opportunitiesdataCollection = opportunitiesdataCollection;
    }

}
