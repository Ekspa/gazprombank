/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "cv", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cv.findAll", query = "SELECT c FROM Cv c")
    , @NamedQuery(name = "Cv.findById", query = "SELECT c FROM Cv c WHERE c.id = :id")
    , @NamedQuery(name = "Cv.findByNameofPerson", query = "SELECT c FROM Cv c WHERE c.nameofPerson = :nameofPerson")
    , @NamedQuery(name = "Cv.findByEmail", query = "SELECT c FROM Cv c WHERE c.email = :email")
    , @NamedQuery(name = "Cv.findByAge", query = "SELECT c FROM Cv c WHERE c.age = :age")
    , @NamedQuery(name = "Cv.findByPhone", query = "SELECT c FROM Cv c WHERE c.phone = :phone")})
public class Cv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Long id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "NameofPerson")
    private String nameofPerson;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Недопустимый адрес электронной почты")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Age")
    private short age;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Недопустимый формат номера телефона/факса (должен иметь формат xxx-xxx-xxxx)")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Size(max = 60)
    @Column(name = "Phone")
    private String phone;
    @JoinColumn(name = "Vacancies_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Vacancies vacanciesid;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cVid")
    private Collection<Answerscv> answerscvCollection;

    public Cv() {
    }

    public Cv(Long id) {
        this.id = id;
    }

    public Cv(Long id, String nameofPerson, String email, short age) {
        this.id = id;
        this.nameofPerson = nameofPerson;
        this.email = email;
        this.age = age;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNameofPerson() {
        return nameofPerson;
    }

    public void setNameofPerson(String nameofPerson) {
        this.nameofPerson = nameofPerson;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public short getAge() {
        return age;
    }

    public void setAge(short age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Vacancies getVacanciesid() {
        return vacanciesid;
    }

    public void setVacanciesid(Vacancies vacanciesid) {
        this.vacanciesid = vacanciesid;
    }

    @XmlTransient
    public Collection<Answerscv> getAnswerscvCollection() {
        return answerscvCollection;
    }

    public void setAnswerscvCollection(Collection<Answerscv> answerscvCollection) {
        this.answerscvCollection = answerscvCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cv)) {
            return false;
        }
        Cv other = (Cv) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Cv[ id=" + id + " ]";
    }
    
}
