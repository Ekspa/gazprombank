/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "dutiesdata", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dutiesdata.findAll", query = "SELECT d FROM Dutiesdata d")
    , @NamedQuery(name = "Dutiesdata.findByIsUsed", query = "SELECT d FROM Dutiesdata d WHERE d.isUsed = :isUsed")
    , @NamedQuery(name = "Dutiesdata.findById", query = "SELECT d FROM Dutiesdata d WHERE d.id = :id")})
public class Dutiesdata implements Serializable {

    @JoinColumn(name = "PropertiesofVacancies_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Propertiesofvacancies propertiesofVacanciesid;

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "IsUsed")
    private boolean isUsed;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "DutiesofVacancies_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Dutiesofvacancies dutiesofVacanciesid;


    public Dutiesdata() {
    }

    public Dutiesdata(Integer id) {
        this.id = id;
    }

    public Dutiesdata(Integer id, boolean isUsed) {
        this.id = id;
        this.isUsed = isUsed;
    }

    public boolean getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(boolean isUsed) {
        this.isUsed = isUsed;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Dutiesofvacancies getDutiesofVacanciesid() {
        return dutiesofVacanciesid;
    }

    public void setDutiesofVacanciesid(Dutiesofvacancies dutiesofVacanciesid) {
        this.dutiesofVacanciesid = dutiesofVacanciesid;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dutiesdata)) {
            return false;
        }
        Dutiesdata other = (Dutiesdata) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Dutiesdata[ id=" + id + " ]";
    }

    public Propertiesofvacancies getPropertiesofVacanciesid() {
        return propertiesofVacanciesid;
    }

    public void setPropertiesofVacanciesid(Propertiesofvacancies propertiesofVacanciesid) {
        this.propertiesofVacanciesid = propertiesofVacanciesid;
    }
    
}
