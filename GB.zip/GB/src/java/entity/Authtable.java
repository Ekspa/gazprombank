/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "authtable", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Authtable.findAll", query = "SELECT a FROM Authtable a")
    , @NamedQuery(name = "Authtable.findByUserId", query = "SELECT a FROM Authtable a WHERE a.authtablePK.userId = :userId")
    , @NamedQuery(name = "Authtable.findByGroupOfUsersid", query = "SELECT a FROM Authtable a WHERE a.authtablePK.groupOfUsersid = :groupOfUsersid")
    , @NamedQuery(name = "Authtable.findByLogin", query = "SELECT a FROM Authtable a WHERE a.login = :login")
    , @NamedQuery(name = "Authtable.findByNameGroup", query = "SELECT a FROM Authtable a WHERE a.nameGroup = :nameGroup")})
public class Authtable implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected AuthtablePK authtablePK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "Login")
    private String login;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "NameGroup")
    private String nameGroup;
    @JoinColumn(name = "GroupOfUsers_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Groupofusers groupofusers;
    @JoinColumn(name = "user_id", referencedColumnName = "id", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private User user;

    public Authtable() {
    }

    public Authtable(AuthtablePK authtablePK) {
        this.authtablePK = authtablePK;
    }

    public Authtable(AuthtablePK authtablePK, String login, String nameGroup) {
        this.authtablePK = authtablePK;
        this.login = login;
        this.nameGroup = nameGroup;
    }

    public Authtable(int userId, int groupOfUsersid) {
        this.authtablePK = new AuthtablePK(userId, groupOfUsersid);
    }

    public AuthtablePK getAuthtablePK() {
        return authtablePK;
    }

    public void setAuthtablePK(AuthtablePK authtablePK) {
        this.authtablePK = authtablePK;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getNameGroup() {
        return nameGroup;
    }

    public void setNameGroup(String nameGroup) {
        this.nameGroup = nameGroup;
    }

    public Groupofusers getGroupofusers() {
        return groupofusers;
    }

    public void setGroupofusers(Groupofusers groupofusers) {
        this.groupofusers = groupofusers;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (authtablePK != null ? authtablePK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Authtable)) {
            return false;
        }
        Authtable other = (Authtable) object;
        if ((this.authtablePK == null && other.authtablePK != null) || (this.authtablePK != null && !this.authtablePK.equals(other.authtablePK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Authtable[ authtablePK=" + authtablePK + " ]";
    }
    
}
