/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "answerscv", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Answerscv.findAll", query = "SELECT a FROM Answerscv a")
    , @NamedQuery(name = "Answerscv.findByIsMatch", query = "SELECT a FROM Answerscv a WHERE a.isMatch = :isMatch")
    , @NamedQuery(name = "Answerscv.findById", query = "SELECT a FROM Answerscv a WHERE a.id = :id")})
public class Answerscv implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "IsMatch")
    private boolean isMatch;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @JoinColumn(name = "CV_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Cv cVid;
    @JoinColumn(name = "RequirementsofVacancies_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Requirementsofvacancies requirementsofVacanciesid;

    public Answerscv() {
    }

    public Answerscv(Integer id) {
        this.id = id;
    }

    public Answerscv(Integer id, boolean isMatch) {
        this.id = id;
        this.isMatch = isMatch;
    }

    public boolean getIsMatch() {
        return isMatch;
    }

    public void setIsMatch(boolean isMatch) {
        this.isMatch = isMatch;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Cv getCVid() {
        return cVid;
    }

    public void setCVid(Cv cVid) {
        this.cVid = cVid;
    }

    public Requirementsofvacancies getRequirementsofVacanciesid() {
        return requirementsofVacanciesid;
    }

    public void setRequirementsofVacanciesid(Requirementsofvacancies requirementsofVacanciesid) {
        this.requirementsofVacanciesid = requirementsofVacanciesid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Answerscv)) {
            return false;
        }
        Answerscv other = (Answerscv) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Answerscv[ id=" + id + " ]";
    }
    
}
