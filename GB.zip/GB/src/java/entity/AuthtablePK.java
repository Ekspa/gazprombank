/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author ADULT
 */
@Embeddable
public class AuthtablePK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "user_id")
    private int userId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "GroupOfUsers_id")
    private int groupOfUsersid;

    public AuthtablePK() {
    }

    public AuthtablePK(int userId, int groupOfUsersid) {
        this.userId = userId;
        this.groupOfUsersid = groupOfUsersid;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getGroupOfUsersid() {
        return groupOfUsersid;
    }

    public void setGroupOfUsersid(int groupOfUsersid) {
        this.groupOfUsersid = groupOfUsersid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) userId;
        hash += (int) groupOfUsersid;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AuthtablePK)) {
            return false;
        }
        AuthtablePK other = (AuthtablePK) object;
        if (this.userId != other.userId) {
            return false;
        }
        if (this.groupOfUsersid != other.groupOfUsersid) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.AuthtablePK[ userId=" + userId + ", groupOfUsersid=" + groupOfUsersid + " ]";
    }
    
}
