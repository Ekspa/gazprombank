/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author ADULT
 */
@Entity
@Table(name = "vacancies", catalog = "gb", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Vacancies.findAll", query = "SELECT v FROM Vacancies v")
    , @NamedQuery(name = "Vacancies.findById", query = "SELECT v FROM Vacancies v WHERE v.id = :id")
    , @NamedQuery(name = "Vacancies.findByName", query = "SELECT v FROM Vacancies v WHERE v.name = :name")
    , @NamedQuery(name = "Vacancies.findByStatus", query = "SELECT v FROM Vacancies v WHERE v.status = :status")
    , @NamedQuery(name = "Vacancies.findByDateCreate", query = "SELECT v FROM Vacancies v WHERE v.dateCreate = :dateCreate")
    , @NamedQuery(name = "Vacancies.findByIsForCopy", query = "SELECT v FROM Vacancies v WHERE v.isForCopy = :isForCopy")
    , @NamedQuery(name = "Vacancies.findByShortDescription", query = "SELECT v FROM Vacancies v WHERE v.shortDescription = :shortDescription")})
public class Vacancies implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 500)
    @Column(name = "Name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "Status")
    private String status;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DateCreate")
    @Temporal(TemporalType.DATE)
    private Date dateCreate;
    @Column(name = "IsForCopy")
    private Boolean isForCopy;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1000)
    @Column(name = "ShortDescription")
    private String shortDescription;
    @JoinColumn(name = "CategoriesVac_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Categoriesvac categoriesVacid;
    @JoinColumn(name = "JobPlaces_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private Jobplaces jobPlacesid;
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    private User userId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vacanciesid")
    private Collection<Cv> cvCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vacanciesid")
    private Collection<Dutiesofvacancies> dutiesofvacanciesCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vacanciesid")
    private Collection<Opportunitiesofvacancies> opportunitiesofvacanciesCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vacanciesid")
    private Collection<Requirementsofvacancies> requirementsofvacanciesCollection;

    public Vacancies() {
    }

    public Vacancies(Integer id) {
        this.id = id;
    }

    public Vacancies(Integer id, String name, String status, Date dateCreate, String shortDescription) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.dateCreate = dateCreate;
        this.shortDescription = shortDescription;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDateCreate() {
        return dateCreate;
    }

    public void setDateCreate(Date dateCreate) {
        this.dateCreate = dateCreate;
    }

    public Boolean getIsForCopy() {
        return isForCopy;
    }

    public void setIsForCopy(Boolean isForCopy) {
        this.isForCopy = isForCopy;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public Categoriesvac getCategoriesVacid() {
        return categoriesVacid;
    }

    public void setCategoriesVacid(Categoriesvac categoriesVacid) {
        this.categoriesVacid = categoriesVacid;
    }

    public Jobplaces getJobPlacesid() {
        return jobPlacesid;
    }

    public void setJobPlacesid(Jobplaces jobPlacesid) {
        this.jobPlacesid = jobPlacesid;
    }

    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }

    @XmlTransient
    public Collection<Cv> getCvCollection() {
        return cvCollection;
    }

    public void setCvCollection(Collection<Cv> cvCollection) {
        this.cvCollection = cvCollection;
    }

    @XmlTransient
    public Collection<Dutiesofvacancies> getDutiesofvacanciesCollection() {
        return dutiesofvacanciesCollection;
    }

    public void setDutiesofvacanciesCollection(Collection<Dutiesofvacancies> dutiesofvacanciesCollection) {
        this.dutiesofvacanciesCollection = dutiesofvacanciesCollection;
    }

    @XmlTransient
    public Collection<Opportunitiesofvacancies> getOpportunitiesofvacanciesCollection() {
        return opportunitiesofvacanciesCollection;
    }

    public void setOpportunitiesofvacanciesCollection(Collection<Opportunitiesofvacancies> opportunitiesofvacanciesCollection) {
        this.opportunitiesofvacanciesCollection = opportunitiesofvacanciesCollection;
    }

    @XmlTransient
    public Collection<Requirementsofvacancies> getRequirementsofvacanciesCollection() {
        return requirementsofvacanciesCollection;
    }

    public void setRequirementsofvacanciesCollection(Collection<Requirementsofvacancies> requirementsofvacanciesCollection) {
        this.requirementsofvacanciesCollection = requirementsofvacanciesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vacancies)) {
            return false;
        }
        Vacancies other = (Vacancies) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Vacancies[ id=" + id + " ]";
    }
    
}
