/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entity.Categoriesvac;
import entity.Jobplaces;
import entity.Propertiesofvacancies;
import entity.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.ServletSecurity.TransportGuarantee;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import jdk.nashorn.internal.ir.BreakNode;
import session.CategoriesvacFacadeLocal;
import session.EntitiesManagerLocal;
import session.JobplacesFacadeLocal;
import session.PropertiesofvacanciesFacadeLocal;
import session.UserFacadeLocal;

/**
 *
 * @author ADULT
 */
@WebServlet(name = "General", urlPatterns = {"/enter",
    "/logout",
    "/edit",
    "/getDataprop",
    "/addProp",
    "/setDataprop"})
@ServletSecurity(
        @HttpConstraint(transportGuarantee = TransportGuarantee.CONFIDENTIAL, rolesAllowed = {"Admin"}))
public class GeneralServlet extends HttpServlet {

    @EJB
    private EntitiesManagerLocal entitiesManager;

    @EJB
    private PropertiesofvacanciesFacadeLocal propertiesofvacanciesFacade;

    @EJB
    private CategoriesvacFacadeLocal categoriesvacFacade;

    @EJB
    private JobplacesFacadeLocal jobplacesFacade;

    @EJB
    private UserFacadeLocal userFacade;

    private String userPath;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        userPath = request.getServletPath();
        HttpSession session = request.getSession(true);
        switch (userPath) {
            case "/edit": {
                List<Jobplaces> Places = jobplacesFacade.findAll();
                Places.sort(Comparator.comparing(Jobplaces::getName));
                request.setAttribute("Places", Places);
                List<Categoriesvac> Categories = categoriesvacFacade.findAll();
                Categories.sort(Comparator.comparing(Categoriesvac::getName));
                request.setAttribute("Categories", Categories);
                userPath = "/Vacancy";
                break;
            }
            case "/getDataprop": {
                String Type = request.getParameter("token");
                String CategoryId = request.getParameter("CategoryId");
                if (Type != null && CategoryId != null && !CategoryId.isEmpty()) {
                    Categoriesvac Category = categoriesvacFacade.find(Integer.parseInt(CategoryId));
                    List<Propertiesofvacancies> Properties = propertiesofvacanciesFacade.findAllByCondition(Short.parseShort(Type), Category);
                    Properties.sort(Comparator.comparing(Propertiesofvacancies::getName));
                    List<Propertiesofvacancies> Chosen = (List<Propertiesofvacancies>) session.getAttribute("Chosen");
                    if (Chosen != null) {
                        Properties.removeIf(Item -> {
                            return Chosen.contains(Item);
                        });
                        
                    }
                    request.setAttribute("Properties", Properties);
                }
                userPath = "/Vacancy";
                break;
            }

            case "/enter": {
                User UserMan = (User) session.getAttribute("User");
                if (UserMan == null) {
                    UserMan = userFacade.findByNameMail(request.getUserPrincipal().getName());
                    session.setAttribute("User", UserMan);
                }
                userPath = "/General";
                break;
            }
            case "/logout": {
                session.invalidate();
                userPath = "/EkspaJob";
                response.sendRedirect(userPath);
                return;

            }
            default: {
                userPath = "/login";
                break;
            }
        }

        // use RequestDispatcher to forward request internally
        String url = "/WEB-INF/enter" + userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        userPath = request.getServletPath();
        HttpSession session = request.getSession(true);
        switch (userPath) {
            case "/setDataprop": {
                String PropId = request.getParameter("PropId");
                userPath = "/Vacancy";
                if (PropId == null || PropId.isEmpty()) {
                    break;
                }
                Propertiesofvacancies Prop = propertiesofvacanciesFacade.find(Integer.parseInt(PropId));
                List<Propertiesofvacancies> Chosen = (List<Propertiesofvacancies>) session.getAttribute("Chosen");
                if (Chosen == null) {
                    Chosen = new ArrayList(0);
                }
                Chosen.add(Prop);
                session.setAttribute("Chosen", Chosen);
                break;
            }
            case "/addProp": {
                String Type = request.getParameter("token");
                String CategoryId = request.getParameter("CategoryId");
                String Name = request.getParameter("Name");                                
                userPath = "/Vacancy";
                if (Type != null && CategoryId != null && Name!=null && !CategoryId.isEmpty() &&  !Name.isEmpty()) {
                    
                     Categoriesvac Category = categoriesvacFacade.find(Integer.parseInt(CategoryId));
                     List<Propertiesofvacancies> Same=propertiesofvacanciesFacade.findbyName(Name,Short.parseShort(Type),Category);
                     if (Same.size()==0) {
                     entitiesManager.addProperty(Name,Short.parseShort(Type),Category);
                     }
                }
                
                break;
            }
            default: {
                userPath = "/login";
                break;
            }
        }
        String url = "/WEB-INF/enter" + userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
