/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Groupofusers;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface GroupofusersFacadeLocal {

    void create(Groupofusers groupofusers);

    void edit(Groupofusers groupofusers);

    void remove(Groupofusers groupofusers);

    Groupofusers find(Object id);

    List<Groupofusers> findAll();

    List<Groupofusers> findRange(int[] range);

    int count();
    
}
