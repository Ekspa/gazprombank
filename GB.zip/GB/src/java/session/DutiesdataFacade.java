/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Dutiesdata;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ADULT
 */
@Stateless
public class DutiesdataFacade extends AbstractFacade<Dutiesdata> implements DutiesdataFacadeLocal {

    @PersistenceContext(unitName = "GBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DutiesdataFacade() {
        super(Dutiesdata.class);
    }
    
}
