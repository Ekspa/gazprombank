/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Opportunitiesofvacancies;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface OpportunitiesofvacanciesFacadeLocal {

    void create(Opportunitiesofvacancies opportunitiesofvacancies);

    void edit(Opportunitiesofvacancies opportunitiesofvacancies);

    void remove(Opportunitiesofvacancies opportunitiesofvacancies);

    Opportunitiesofvacancies find(Object id);

    List<Opportunitiesofvacancies> findAll();

    List<Opportunitiesofvacancies> findRange(int[] range);

    int count();
    
}
