/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Jobplaces;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface JobplacesFacadeLocal {

    void create(Jobplaces jobplaces);

    void edit(Jobplaces jobplaces);

    void remove(Jobplaces jobplaces);

    Jobplaces find(Object id);

    List<Jobplaces> findAll();

    List<Jobplaces> findRange(int[] range);

    int count();
    
}
