/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Categoriesvac;
import entity.Propertiesofvacancies;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ADULT
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class EntitiesManager implements EntitiesManagerLocal {
    
    @Resource
    private SessionContext context;
    
    @PersistenceContext(unitName = "GBPU")
    private EntityManager em;

    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addProperty(String Name, short Type, Categoriesvac Category) {
       try {
            Propertiesofvacancies Property = new Propertiesofvacancies();
            Property.setName(Name);
            Property.setType(Type);
            Property.setCategoriesVacid(Category);          
            em.persist(Property);
            em.flush();
        } catch (Exception e) {
            context.setRollbackOnly();
        }
    }

    
}
