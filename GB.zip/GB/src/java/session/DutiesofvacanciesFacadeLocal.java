/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Dutiesofvacancies;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface DutiesofvacanciesFacadeLocal {

    void create(Dutiesofvacancies dutiesofvacancies);

    void edit(Dutiesofvacancies dutiesofvacancies);

    void remove(Dutiesofvacancies dutiesofvacancies);

    Dutiesofvacancies find(Object id);

    List<Dutiesofvacancies> findAll();

    List<Dutiesofvacancies> findRange(int[] range);

    int count();
    
}
