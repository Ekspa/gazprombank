/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Opportunitiesdata;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface OpportunitiesdataFacadeLocal {

    void create(Opportunitiesdata opportunitiesdata);

    void edit(Opportunitiesdata opportunitiesdata);

    void remove(Opportunitiesdata opportunitiesdata);

    Opportunitiesdata find(Object id);

    List<Opportunitiesdata> findAll();

    List<Opportunitiesdata> findRange(int[] range);

    int count();
    
}
