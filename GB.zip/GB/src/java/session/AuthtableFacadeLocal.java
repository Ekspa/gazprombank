/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Authtable;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author ADULT
 */
@Local
public interface AuthtableFacadeLocal {

    void create(Authtable authtable);

    void edit(Authtable authtable);

    void remove(Authtable authtable);

    Authtable find(Object id);

    List<Authtable> findAll();

    List<Authtable> findRange(int[] range);

    int count();
    
}
