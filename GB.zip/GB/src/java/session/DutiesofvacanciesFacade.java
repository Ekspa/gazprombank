/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Dutiesofvacancies;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ADULT
 */
@Stateless
public class DutiesofvacanciesFacade extends AbstractFacade<Dutiesofvacancies> implements DutiesofvacanciesFacadeLocal {

    @PersistenceContext(unitName = "GBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DutiesofvacanciesFacade() {
        super(Dutiesofvacancies.class);
    }
    
}
