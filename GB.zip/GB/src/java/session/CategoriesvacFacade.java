/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Categoriesvac;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ADULT
 */
@Stateless
public class CategoriesvacFacade extends AbstractFacade<Categoriesvac> implements CategoriesvacFacadeLocal {

    @PersistenceContext(unitName = "GBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CategoriesvacFacade() {
        super(Categoriesvac.class);
    }
    
}
