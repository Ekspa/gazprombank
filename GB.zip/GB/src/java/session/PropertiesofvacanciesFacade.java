/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import entity.Categoriesvac;
import entity.Propertiesofvacancies;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author ADULT
 */
@Stateless
public class PropertiesofvacanciesFacade extends AbstractFacade<Propertiesofvacancies> implements PropertiesofvacanciesFacadeLocal {

    @PersistenceContext(unitName = "GBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PropertiesofvacanciesFacade() {
        super(Propertiesofvacancies.class);
    }

    @Override
    public List<Propertiesofvacancies> findAllByCondition(short Type, Categoriesvac Category) {
        List<Propertiesofvacancies> ListUser;
        ListUser = em.createNamedQuery("Propertiesofvacancies.findByCond").setParameter("idCategory", Category).setParameter("Type", Type).getResultList();
        return ListUser;
    }

    @Override
    public List<Propertiesofvacancies> findbyName(String Name, short Type, Categoriesvac Category) {
        List<Propertiesofvacancies> ListUser;
        ListUser = em.createNamedQuery("Propertiesofvacancies.findByName").setParameter("idCategory", Category).setParameter("Type", Type).setParameter("Name", Name).getResultList();
        return ListUser;
    }
    
}
